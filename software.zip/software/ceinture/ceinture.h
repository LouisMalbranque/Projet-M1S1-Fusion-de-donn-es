#include <Wire.h>
#include "MAX30100_PulseOximeter.h"
#include <OneWire.h> //Librairie du bus OneWire
#include <DallasTemperature.h> //Librairie du capteur
#include <EEPROM.h>
#include <arduinoFFT.h>

#define SAMPLE_NUMBER 128
#define PIN_RESPIRATORY_SENSOR A0

class Ceinture{
  private:
  // heart rate sensor variables
  double heartRate=70;
  PulseOximeter pox;

  // respiratory rate sensor
  byte vReal[SAMPLE_NUMBER];
  byte vImag[SAMPLE_NUMBER];
  int i=0;
  double respiratoryRate;
  arduinoFFT FFT = arduinoFFT();
  

  // temperature sensor variables
  double temperature=0;
  double lastTemp = 0;
  int tempTimeSample = 1000;
  int divider = 1;

  public:
  void begin();
  void updateHR();
  void updateRR();
  double getTemperature();
  double getHeartRate();
  double getRespiratoryRate();
  void display();
};

